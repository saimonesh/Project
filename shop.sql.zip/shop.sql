-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 08, 2018 at 08:05 AM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `apriori`
--

CREATE TABLE IF NOT EXISTS `apriori` (
  `user_id` varchar(10) DEFAULT NULL,
  `VEG04` int(2) NOT NULL DEFAULT '0',
  `SNA10` int(2) NOT NULL DEFAULT '0',
  `SNA09` int(2) NOT NULL DEFAULT '0',
  `FRU01` int(2) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `apriori`
--

INSERT INTO `apriori` (`user_id`, `VEG04`, `SNA10`, `SNA09`, `FRU01`) VALUES
('sai4360', 1, 1, 1, 1),
('vig6789', 0, 0, 0, 1),
('sai2460', 0, 1, 0, 0),
('SAR2664', 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `customer_details`
--

CREATE TABLE IF NOT EXISTS `customer_details` (
  `Id` varchar(10) NOT NULL,
  `Name` varchar(15) NOT NULL,
  `phone_no` varchar(10) NOT NULL,
  `Type` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_details`
--

INSERT INTO `customer_details` (`Id`, `Name`, `phone_no`, `Type`) VALUES
('sai4360', 'saimonesh', '9840543605', 'Snacks'),
('vig6789', 'vignesh', '9444567895', 'General'),
('SAR2664', 'SARAn', '9940426640', 'Fruits');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE IF NOT EXISTS `item` (
  `ITEM_ID` varchar(6) NOT NULL,
  `ITEM_NAME` varchar(15) NOT NULL,
  `QUANTITY` int(5) NOT NULL,
  `PRICE` int(5) NOT NULL,
  `Type` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`ITEM_ID`, `ITEM_NAME`, `QUANTITY`, `PRICE`, `Type`) VALUES
('FRU01', 'APPLE', 0, 100, 'Fruits'),
('FRU02', 'APRICOT', 50, 120, 'Fruits'),
('FRU03', 'AVOCADO', 50, 120, 'Fruits'),
('VEG04', 'Carrot', 50, 120, 'Vegetables'),
('VEG05', 'Beetroot', 50, 120, 'Vegetables'),
('VEG06', 'TOMATO', 50, 60, 'Vegetables'),
('GEN07', 'MILK', 50, 50, 'General'),
('GEN08', 'CURD', 50, 50, 'General'),
('SNA09', 'LAYS', 50, 80, 'Snacks'),
('SNA10', 'Biscuits', 50, 70, 'Snacks'),
('FRU12', 'MANGO', 50, 45, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS'),
('FRU13', 'KIWI', 50, 45, 'FRUITS'),
('FRU14', 'POMOGRANADE', 50, 50, 'FRUITS');

-- --------------------------------------------------------

--
-- Table structure for table `records`
--

CREATE TABLE IF NOT EXISTS `records` (
  `ID` varchar(6) NOT NULL,
  `User_id` varchar(10) NOT NULL,
  `COMPANY` varchar(10) NOT NULL,
  `QUANTITY` int(7) NOT NULL,
  `DATE` varchar(10) NOT NULL,
  `PRICE` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `records`
--

INSERT INTO `records` (`ID`, `User_id`, `COMPANY`, `QUANTITY`, `DATE`, `PRICE`) VALUES
('FRU01', 'sai4360', 'COMP-1', 26, '2018/02/11', 50),
('VEG04', 'sai4360', 'COMP-1', 110, '2018/02/11', 75),
('SNA09', 'sai4360', 'COMP-1', 100, '21/10/2014', 30),
('SNA10', 'sai4360', 'COMP-1', 20, '2018/02/12', 20),
('FRU01', 'vig6789', 'COMP-1', 20, '12/12/2017', 60),
('SNA10', 'sai2460', 'COMP-1', 20, '21/12/2014', 60),
('FRU01', 'SAR2664', 'COMP-1', 26, '2018/03/20', 50),
('FRU01', 'SAR2664', 'COMP-1', 100, '2018/03/20', 70),
('FRU01', 'SAR2664', 'COMP-1', 175, '2018/03/20', 100);

-- --------------------------------------------------------

--
-- Table structure for table `year`
--

CREATE TABLE IF NOT EXISTS `year` (
  `Item_id` varchar(20) NOT NULL,
  `quantity` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `year`
--

INSERT INTO `year` (`Item_id`, `quantity`) VALUES
('Feb', 110),
('Feb', 26),
('Jun', 20),
('Mar', 26),
('Mar', 100),
('Mar', 175),
('Feb', 26),
('Jun', 20),
('Mar', 26),
('Mar', 100),
('Mar', 175),
('Feb', 26),
('Jun', 20),
('Mar', 26),
('Mar', 100),
('Mar', 175),
('Feb', 26),
('Jun', 20),
('Mar', 26),
('Mar', 100),
('Mar', 175),
('Feb', 26),
('Jun', 20),
('Mar', 26),
('Mar', 100),
('Mar', 175),
('Feb', 26),
('Jun', 20),
('Mar', 26),
('Mar', 100),
('Mar', 175),
('Feb', 26),
('Jun', 20),
('Mar', 26),
('Mar', 100),
('Mar', 175);

-- --------------------------------------------------------

--
-- Table structure for table `year2`
--

CREATE TABLE IF NOT EXISTS `year2` (
  `Item_id` varchar(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `year2`
--

INSERT INTO `year2` (`Item_id`, `quantity`) VALUES
('Jan', 0),
('Feb', 292),
('Mar', 2107),
('Apr', 0),
('May', 0),
('Jun', 140),
('Jul', 0),
('Aug', 0),
('Sep', 0),
('Oct', 0),
('Nov', 0),
('Dec', 0);
