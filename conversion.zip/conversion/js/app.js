$(document).ready(function(){
	$.ajax(
		{
			url:"http://localhost/conversion/data.php",
			method:"GET",
			success: function(data){
				console.log(data);
				var item=[];
				var quan=[];
				for (var i in data)
				{
					
					item.push(data[i].Item_id);
					quan.push(data[i].quantity);
				}	
					var chardataset={
						labels:item,
						datasets:[
						{
							label:'Sold',backgroundColor:'rgba(200,200,200,0.75)',
							borderColor:'rgba(200,200,200,0.75)',
							hoverBackgroundColor:'rgba(200,200,200,1)',
							hoverBorderColor:'rgba(200,200,200,1)',
							data:quan	
						}]
					
					
				};
				var ctx=$("#mycanvas");
				var bargraph=new Chart(ctx,{
					type:'line',
					data:chardataset
				});
			},
			error: function(data){console.log(data);}
		});

});